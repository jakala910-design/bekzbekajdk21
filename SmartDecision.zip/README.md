# SmartDecision (Java 21, Eclipse Temurin / Adoptium)

Консольная система принятия решений на условных операторах. Реализованы все 25 заданий ТЗ.

## Запуск в IntelliJ IDEA
1. New Project → Name: `SmartDecision`, Language: Java, Build system: IntelliJ, JDK: Temurin 21.
2. Скопируйте файлы из папки `src` в папку `src` проекта.
3. Откройте `Main.java` → зелёный треугольник → Run Main.main().
4. Учебный вход: логин `admin`, пароль `java21`.

## Запуск из терминала
    javac -encoding UTF-8 -d out src/*.java
    java -cp out Main

(В Windows cmd для русского текста выполните `chcp 65001` перед запуском.)

## Соответствие заданий
| Задания | Где реализовано | Меню |
|---|---|---|
| 1 | Menu.java | главное меню |
| 2 | Validation.java, DecisionSystem.validationDemo | 1 → 1 |
| 3, 4 | userStatus, numericIndicator | 1 → 2, 3 |
| 5 | login (3 попытки) | вход при запуске |
| 6–10 | checkAge, installment, benefitStatus, notBlockedCheck, nestedDecision | 2 |
| 11–15 | discount, financialState, grade, securityCheck, recommendation | 3 |
| 16–20 | sections, serviceCategory, tariffCalculator, errorHandling, combinedScenarios | 4 |
| 21–24 | customModule (фитнес-клуб), dataAnalysis, levelOfReadiness, personalRecommendations | 5 |
| 25 | finalDecision + Report.java | 6 и 7 |
