/**
 * Отображение меню и обработка выбора пользователя (задание 1).
 */
public class Menu {

    private final DecisionSystem system = new DecisionSystem();

    /** Запуск: сначала проверка доступа, затем главное меню. */
    public void start() {
        if (!system.login()) {
            return;
        }
        while (true) {
            showMainMenu();
            int choice = Validation.readInt("Ваш выбор: ", 0, 7);
            switch (choice) {
                case 1 -> basicMenu();
                case 2 -> logicMenu();
                case 3 -> practiceMenu();
                case 4 -> switchMenu();
                case 5 -> customMenu();
                case 6 -> {
                    system.finalDecision();
                    Validation.pause();
                }
                case 7 -> {
                    Report.print();
                    Validation.pause();
                }
                case 0 -> {
                    Report.print();
                    System.out.println("До свидания!");
                    return;
                }
                default -> System.out.println("Неизвестный пункт меню.");
            }
        }
    }

    private void showMainMenu() {
        System.out.println("\n==================================================");
        System.out.println("                  SMART DECISION");
        System.out.println("        Система принятия решений (Java 21)");
        System.out.println("==================================================");
        System.out.println("1. Базовые проверки (ввод, статус, доступ)");
        System.out.println("2. Логические операторы (&&, ||, !, вложенные if)");
        System.out.println("3. Практические задачи (скидки, финансы, риски)");
        System.out.println("4. switch и комбинированные условия");
        System.out.println("5. Индивидуальный модуль и анализ данных");
        System.out.println("6. Комплексная оценка (финальный модуль)");
        System.out.println("7. Итоговый отчёт");
        System.out.println("0. Выход");
        System.out.println("==================================================");
    }

    private void basicMenu() {
        while (true) {
            System.out.println("\n--- Базовые проверки ---");
            System.out.println("1. Проверка введённых данных\n2. Статус пользователя\n3. Числовой показатель\n0. Назад");
            int c = Validation.readInt("Выбор: ", 0, 3);
            switch (c) {
                case 1 -> system.validationDemo();
                case 2 -> system.userStatus();
                case 3 -> system.numericIndicator();
                case 0 -> { return; }
                default -> { }
            }
        }
    }

    private void logicMenu() {
        while (true) {
            System.out.println("\n--- Логические операторы ---");
            System.out.println("1. Возрастная категория (if–else if)\n2. Рассрочка (&&)\n3. Льготный статус (||)");
            System.out.println("4. Проверка блокировки (!)\n5. Оформление заказа (вложенные if)\n0. Назад");
            int c = Validation.readInt("Выбор: ", 0, 5);
            switch (c) {
                case 1 -> system.checkAge();
                case 2 -> system.installment();
                case 3 -> system.benefitStatus();
                case 4 -> system.notBlockedCheck();
                case 5 -> system.nestedDecision();
                case 0 -> { return; }
                default -> { }
            }
        }
    }

    private void practiceMenu() {
        while (true) {
            System.out.println("\n--- Практические задачи ---");
            System.out.println("1. Скидки\n2. Финансовое состояние\n3. Оценка результатов");
            System.out.println("4. Проверка безопасности\n5. Рекомендации\n0. Назад");
            int c = Validation.readInt("Выбор: ", 0, 5);
            switch (c) {
                case 1 -> system.discount();
                case 2 -> system.financialState();
                case 3 -> system.grade();
                case 4 -> system.securityCheck();
                case 5 -> system.recommendation();
                case 0 -> { return; }
                default -> { }
            }
        }
    }

    private void switchMenu() {
        while (true) {
            System.out.println("\n--- switch и комбинированные условия ---");
            System.out.println("1. Разделы программы\n2. Категория услуги\n3. Калькулятор стоимости");
            System.out.println("4. Обработка ошибок выбора\n5. Комбинированные сценарии\n0. Назад");
            int c = Validation.readInt("Выбор: ", 0, 5);
            switch (c) {
                case 1 -> system.sections();
                case 2 -> system.serviceCategory();
                case 3 -> system.tariffCalculator();
                case 4 -> system.errorHandling();
                case 5 -> system.combinedScenarios();
                case 0 -> { return; }
                default -> { }
            }
        }
    }

    private void customMenu() {
        while (true) {
            System.out.println("\n--- Индивидуальный модуль ---");
            System.out.println("1. Фитнес-клуб: подбор абонемента\n2. Анализ кандидата (5 параметров)");
            System.out.println("3. Уровень подготовки (3 уровня)\n4. Персональные рекомендации\n0. Назад");
            int c = Validation.readInt("Выбор: ", 0, 4);
            switch (c) {
                case 1 -> system.customModule();
                case 2 -> system.dataAnalysis();
                case 3 -> system.levelOfReadiness();
                case 4 -> system.personalRecommendations();
                case 0 -> { return; }
                default -> { }
            }
        }
    }
}
