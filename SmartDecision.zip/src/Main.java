import java.io.PrintStream;
import java.nio.charset.StandardCharsets;

/**
 * Точка входа: запуск программы и вызов главного меню.
 */
public class Main {
    public static void main(String[] args) {
        // Вывод в UTF-8, чтобы русский текст корректно отображался
        System.setOut(new PrintStream(System.out, true, StandardCharsets.UTF_8));
        new Menu().start();
    }
}
