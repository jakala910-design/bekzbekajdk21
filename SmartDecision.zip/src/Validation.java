import java.nio.charset.StandardCharsets;
import java.util.Scanner;

/**
 * Проверка корректности введённых данных (задание 2).
 * Все методы повторяют запрос, пока пользователь не введёт допустимое значение.
 */
public class Validation {

    private static final Scanner IN = new Scanner(System.in, StandardCharsets.UTF_8);

    /** Читает непустую строку. */
    public static String readText(String prompt) {
        while (true) {
            String s = readLine(prompt);
            if (s.isEmpty()) {
                System.out.println("  [Ошибка] Пустое значение. Повторите ввод.");
            } else {
                return s;
            }
        }
    }

    /** Читает целое число в диапазоне [min; max]. */
    public static int readInt(String prompt, int min, int max) {
        while (true) {
            String s = readLine(prompt);
            if (s.isEmpty()) {
                System.out.println("  [Ошибка] Пустое значение. Повторите ввод.");
                continue;
            }
            try {
                int value = Integer.parseInt(s);
                if (value < min || value > max) {
                    System.out.println("  [Ошибка] Число должно быть от " + min + " до " + max + ".");
                } else {
                    return value;
                }
            } catch (NumberFormatException e) {
                System.out.println("  [Ошибка] «" + s + "» — не целое число.");
            }
        }
    }

    /** Читает вещественное число в диапазоне [min; max]. Допускается запятая вместо точки. */
    public static double readDouble(String prompt, double min, double max) {
        while (true) {
            String s = readLine(prompt).replace(',', '.');
            if (s.isEmpty()) {
                System.out.println("  [Ошибка] Пустое значение. Повторите ввод.");
                continue;
            }
            try {
                double value = Double.parseDouble(s);
                if (Double.isNaN(value) || Double.isInfinite(value) || value < min || value > max) {
                    System.out.println("  [Ошибка] Число должно быть от " + min + " до " + max + ".");
                } else {
                    return value;
                }
            } catch (NumberFormatException e) {
                System.out.println("  [Ошибка] «" + s + "» — не число.");
            }
        }
    }

    /** Читает ответ «да/нет». */
    public static boolean readYesNo(String prompt) {
        while (true) {
            String s = readLine(prompt + " (да/нет): ").toLowerCase();
            if (s.equals("да") || s.equals("д") || s.equals("y") || s.equals("yes")) {
                return true;
            }
            if (s.equals("нет") || s.equals("н") || s.equals("n") || s.equals("no")) {
                return false;
            }
            System.out.println("  [Ошибка] Введите «да» или «нет».");
        }
    }

    /** Ожидание нажатия Enter. */
    public static void pause() {
        readLine("\nНажмите Enter, чтобы продолжить...");
    }

    private static String readLine(String prompt) {
        System.out.print(prompt);
        if (!IN.hasNextLine()) {
            System.out.println("\nВвод завершён. Выход из программы.");
            System.exit(0);
        }
        return IN.nextLine().trim();
    }
}
