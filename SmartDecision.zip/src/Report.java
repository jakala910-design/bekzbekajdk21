import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;

/**
 * Формирование и вывод итогового отчёта (задание 25).
 * Каждое принятое системой решение записывается в журнал.
 */
public class Report {

    private static final List<String> LOG = new ArrayList<>();

    /** Запись решения в журнал. */
    public static void add(String module, String result) {
        LOG.add(module + " → " + result);
    }

    public static int count() {
        return LOG.size();
    }

    /** Печатает итоговый отчёт за сеанс. */
    public static void print() {
        String time = LocalDateTime.now().format(DateTimeFormatter.ofPattern("dd.MM.yyyy HH:mm"));
        System.out.println("\n==================================================");
        System.out.println("          ИТОГОВЫЙ ОТЧЁТ SMART DECISION");
        System.out.println("          " + time);
        System.out.println("==================================================");
        if (LOG.isEmpty()) {
            System.out.println("Решений в этом сеансе ещё не принималось.");
        } else {
            for (int i = 0; i < LOG.size(); i++) {
                System.out.println((i + 1) + ". " + LOG.get(i));
            }
            System.out.println("--------------------------------------------------");
            System.out.println("Всего принято решений: " + LOG.size());
        }
        System.out.println("==================================================");
    }

    /** Блок с итоговым решением для комплексной оценки. */
    public static void printDecision(String name, String decision, List<String> reasons) {
        System.out.println("\n--------------- РЕШЕНИЕ СИСТЕМЫ ---------------");
        System.out.println("Клиент : " + name);
        System.out.println("Решение: " + decision);
        System.out.println("Причины:");
        for (String r : reasons) {
            System.out.println("  • " + r);
        }
        System.out.println("-----------------------------------------------");
    }
}
