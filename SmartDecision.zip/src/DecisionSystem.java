import java.util.ArrayList;
import java.util.List;

/**
 * Основная логика принятия решений и условные операторы (задания 3–25).
 * Каждый метод помечен номером задания из технического задания.
 */
public class DecisionSystem {

    private static final String VALID_LOGIN = "admin";
    private static final String VALID_PASSWORD = "java21";

    // ===================== Блок 1. Базовые проверки (1–5) =====================

    /** Задание 2: демонстрация проверки ввода. */
    public void validationDemo() {
        System.out.println("\n--- Проверка вводимых данных ---");
        String name = Validation.readText("Введите ваше имя: ");
        int number = Validation.readInt("Введите целое число от 1 до 100: ", 1, 100);
        System.out.println("Данные корректны: " + name + ", число " + number);
        Report.add("Проверка ввода", "данные приняты (" + name + ", " + number + ")");
    }

    /** Задание 3: статус пользователя (активный / неактивный / заблокированный). */
    public void userStatus() {
        System.out.println("\n--- Статус пользователя ---");
        boolean blocked = Validation.readYesNo("Пользователь заблокирован администратором?");
        int days = Validation.readInt("Дней с последнего входа (0–3650): ", 0, 3650);
        String status;
        if (blocked) {
            status = "ЗАБЛОКИРОВАННЫЙ";
        } else if (days <= 30) {
            status = "АКТИВНЫЙ";
        } else {
            status = "НЕАКТИВНЫЙ";
        }
        System.out.println("Статус пользователя: " + status);
        Report.add("Статус пользователя", status);
    }

    /** Задание 4: числовой показатель, три возможных результата. */
    public void numericIndicator() {
        System.out.println("\n--- Числовой показатель ---");
        double value = Validation.readDouble("Введите показатель (0–100): ", 0, 100);
        String result;
        if (value < 40) {
            result = "Низкий показатель";
        } else if (value < 70) {
            result = "Средний показатель";
        } else {
            result = "Высокий показатель";
        }
        System.out.println(result);
        Report.add("Числовой показатель " + value, result);
    }

    /** Задание 5: проверка доступа (логин и пароль). Три попытки. */
    public boolean login() {
        System.out.println("\n--- Вход в систему (учебные данные: " + VALID_LOGIN + " / " + VALID_PASSWORD + ") ---");
        for (int attempt = 1; attempt <= 3; attempt++) {
            String login = Validation.readText("Логин: ");
            String password = Validation.readText("Пароль: ");
            if (login.equals(VALID_LOGIN) && password.equals(VALID_PASSWORD)) {
                System.out.println("Доступ разрешён. Добро пожаловать, " + login + "!");
                Report.add("Проверка доступа", "вход выполнен с попытки " + attempt);
                return true;
            }
            System.out.println("[Предупреждение] Неверный логин или пароль. Осталось попыток: " + (3 - attempt));
        }
        System.out.println("Доступ запрещён: превышено число попыток.");
        return false;
    }

    // ===================== Блок 2. Логические операторы (6–10) =====================

    /** Задание 6: возрастные категории (if – else if), пять категорий. */
    public void checkAge() {
        System.out.println("\n--- Возрастная категория ---");
        int age = Validation.readInt("Введите возраст (0–120): ", 0, 120);
        String category;
        if (age < 14) {
            category = "Ребёнок";
        } else if (age < 18) {
            category = "Подросток";
        } else if (age < 30) {
            category = "Молодой взрослый";
        } else if (age < 60) {
            category = "Взрослый";
        } else {
            category = "Пенсионная категория";
        }
        System.out.println("Возраст " + age + " → " + category);
        Report.add("Возраст " + age, category);
    }

    /** Задание 7: оператор && — рассрочка только при выполнении двух условий. */
    public void installment() {
        System.out.println("\n--- Рассрочка (нужны ОБА условия) ---");
        int age = Validation.readInt("Возраст: ", 0, 120);
        double income = Validation.readDouble("Ежемесячный доход (ден. ед.): ", 0, 1_000_000_000);
        String result;
        if (age >= 18 && income >= 150_000) {
            result = "Рассрочка одобрена";
        } else {
            result = "В рассрочке отказано (нужен возраст от 18 и доход от 150 000)";
        }
        System.out.println(result);
        Report.add("Рассрочка", result);
    }

    /** Задание 8: оператор || — льготный статус при выполнении хотя бы одного условия. */
    public void benefitStatus() {
        System.out.println("\n--- Льготный статус (достаточно ОДНОГО условия) ---");
        int age = Validation.readInt("Возраст: ", 0, 120);
        boolean student = Validation.readYesNo("Вы студент?");
        boolean disability = Validation.readYesNo("Есть инвалидность?");
        String result;
        if (age >= 60 || student || disability) {
            result = "Льготный статус присвоен";
        } else {
            result = "Льготный статус не предусмотрен";
        }
        System.out.println(result);
        Report.add("Льготный статус", result);
    }

    /** Задание 9: оператор ! — пользователь не заблокирован. */
    public void notBlockedCheck() {
        System.out.println("\n--- Проверка отрицательного состояния ---");
        boolean blocked = Validation.readYesNo("Аккаунт заблокирован?");
        boolean expired = Validation.readYesNo("Срок подписки истёк?");
        String result;
        if (!blocked && !expired) {
            result = "Аккаунт не заблокирован, подписка действует — работа разрешена";
        } else if (blocked) {
            result = "Аккаунт заблокирован — работа запрещена";
        } else {
            result = "Подписка истекла — требуется продление";
        }
        System.out.println(result);
        Report.add("Проверка блокировки", result);
    }

    /** Задание 10: вложенные if — три последовательные проверки. */
    public void nestedDecision() {
        System.out.println("\n--- Оформление заказа (вложенные проверки) ---");
        boolean registered = Validation.readYesNo("Пользователь зарегистрирован?");
        String result;
        if (registered) {
            int age = Validation.readInt("Возраст: ", 0, 120);
            if (age >= 18) {
                boolean docs = Validation.readYesNo("Документы подтверждены?");
                if (docs) {
                    double balance = Validation.readDouble("Баланс счёта: ", 0, 1_000_000_000);
                    double price = Validation.readDouble("Стоимость заказа: ", 0, 1_000_000_000);
                    if (balance >= price) {
                        result = "Заказ оформлен";
                    } else {
                        result = "Отказ: недостаточно средств (не хватает " + (price - balance) + ")";
                    }
                } else {
                    result = "Отказ: документы не подтверждены";
                }
            } else {
                result = "Отказ: пользователь несовершеннолетний";
            }
        } else {
            result = "Отказ: сначала нужно зарегистрироваться";
        }
        System.out.println(result);
        Report.add("Оформление заказа", result);
    }

    // ===================== Блок 3. Практическое применение (11–15) =====================

    /** Задание 11: скидка зависит от суммы покупки и статуса клиента. */
    public void discount() {
        System.out.println("\n--- Расчёт скидки ---");
        double sum = Validation.readDouble("Сумма покупки: ", 0, 1_000_000_000);
        System.out.println("Статус клиента: 1 — обычный, 2 — серебряный, 3 — золотой");
        int status = Validation.readInt("Выберите статус: ", 1, 3);
        int percent = 0;
        if (status == 1) {
            if (sum >= 10_000) percent = 5;
        } else if (status == 2) {
            if (sum >= 10_000) percent = 12;
            else if (sum >= 3_000) percent = 8;
            else percent = 3;
        } else {
            if (sum >= 10_000) percent = 20;
            else if (sum >= 3_000) percent = 15;
            else percent = 10;
        }
        double total = sum * (100 - percent) / 100.0;
        System.out.printf("Скидка: %d%%. К оплате: %.2f%n", percent, total);
        Report.add("Скидка", percent + "% (к оплате " + String.format("%.2f", total) + ")");
    }

    /** Задание 12: финансовое состояние по доходам и расходам. */
    public void financialState() {
        System.out.println("\n--- Финансовое состояние ---");
        double income = Validation.readDouble("Ежемесячный доход: ", 0, 1_000_000_000);
        double expenses = Validation.readDouble("Ежемесячные расходы: ", 0, 1_000_000_000);
        String status;
        if (income == 0 && expenses == 0) {
            status = "Недостаточно данных";
        } else if (expenses > income) {
            status = "Дефицит бюджета — расходы превышают доходы";
        } else if (income > 0 && (income - expenses) / income >= 0.3) {
            status = "Отличное состояние — откладывается 30% и более";
        } else if (income > 0 && (income - expenses) / income >= 0.1) {
            status = "Стабильное состояние";
        } else {
            status = "Зона риска — почти весь доход тратится";
        }
        System.out.printf("Баланс за месяц: %.2f%n", income - expenses);
        System.out.println(status);
        Report.add("Финансовое состояние", status);
    }

    /** Задание 13: оценка результатов по баллам. */
    public void grade() {
        System.out.println("\n--- Оценка результатов ---");
        int points = Validation.readInt("Введите баллы (0–100): ", 0, 100);
        int mark;
        if (points >= 90) mark = 5;
        else if (points >= 75) mark = 4;
        else if (points >= 50) mark = 3;
        else mark = 2;
        String passed = mark >= 3 ? "тест ПРОЙДЕН" : "тест НЕ пройден";
        System.out.println("Баллы: " + points + ", оценка: " + mark + ", " + passed);
        Report.add("Оценка " + points + " баллов", "оценка " + mark + ", " + passed);
    }

    /** Задание 14: уровень риска безопасности по нескольким параметрам. */
    public void securityCheck() {
        System.out.println("\n--- Проверка безопасности ---");
        int passLen = Validation.readInt("Длина пароля (символов): ", 0, 200);
        boolean twoFa = Validation.readYesNo("Включена двухфакторная аутентификация?");
        boolean publicWifi = Validation.readYesNo("Вход выполняется через публичный Wi-Fi?");
        boolean outdated = Validation.readYesNo("Программное обеспечение устарело?");
        int risk = 0;
        if (passLen < 8) risk += 3;
        else if (passLen < 12) risk += 1;
        if (!twoFa) risk += 2;
        if (publicWifi) risk += 2;
        if (outdated) risk += 2;
        String level;
        if (risk <= 1) level = "НИЗКИЙ";
        else if (risk <= 4) level = "СРЕДНИЙ";
        else level = "ВЫСОКИЙ";
        System.out.println("Баллы риска: " + risk + " → уровень риска " + level);
        Report.add("Безопасность", "уровень риска " + level + " (" + risk + " б.)");
    }

    /** Задание 15: рекомендации по характеристикам пользователя. */
    public void recommendation() {
        System.out.println("\n--- Система рекомендаций ---");
        int hours = Validation.readInt("Сколько часов в неделю готовы учиться (0–80): ", 0, 80);
        boolean hasExperience = Validation.readYesNo("Есть опыт программирования?");
        String rec;
        if (hours < 5) {
            rec = "Короткие видеоуроки и практика по 20 минут в день";
        } else if (!hasExperience) {
            rec = "Начать с основ Java: переменные, условия, циклы (книга + задачи)";
        } else if (hours >= 20) {
            rec = "Интенсивный курс по ООП и коллекциям, затем мини-проект";
        } else {
            rec = "Курс по ООП и решение 2–3 задач в неделю";
        }
        System.out.println("Рекомендация: " + rec);
        Report.add("Рекомендация", rec);
    }

    // ===================== Блок 4. switch и комбинированные условия (16–20) =====================

    /** Задание 16: переключение между разделами через switch (6 разделов). */
    public void sections() {
        while (true) {
            System.out.println("\n--- Разделы программы ---");
            System.out.println("1. Главная\n2. Профиль\n3. Услуги\n4. Настройки\n5. Помощь\n6. О программе\n0. Назад");
            int choice = Validation.readInt("Выберите раздел: ", 0, 6);
            if (choice == 0) {
                return;
            }
            switch (choice) {
                case 1 -> System.out.println("[Главная] Добро пожаловать в Smart Decision!");
                case 2 -> System.out.println("[Профиль] Имя: admin, роль: администратор.");
                case 3 -> System.out.println("[Услуги] Консультации, обучение, поддержка, разработка.");
                case 4 -> System.out.println("[Настройки] Язык: русский, тема: светлая.");
                case 5 -> System.out.println("[Помощь] Выберите пункт меню и следуйте подсказкам.");
                case 6 -> System.out.println("[О программе] Smart Decision, Java 21 (Eclipse Temurin).");
                default -> System.out.println("Неизвестный раздел.");
            }
            Report.add("Раздел программы", "открыт раздел №" + choice);
        }
    }

    /** Задание 17: выбор категории услуги. */
    public void serviceCategory() {
        System.out.println("\n--- Категории услуг ---");
        System.out.println("1. Консультация\n2. Обучение\n3. Техподдержка\n4. Разработка");
        int c = Validation.readInt("Выберите категорию: ", 1, 4);
        String name;
        String features;
        switch (c) {
            case 1 -> { name = "Консультация"; features = "разбор задачи, план действий, ответы на вопросы"; }
            case 2 -> { name = "Обучение"; features = "курсы, практика, проверка домашних заданий"; }
            case 3 -> { name = "Техподдержка"; features = "приём заявок, диагностика, удалённая помощь"; }
            case 4 -> { name = "Разработка"; features = "проектирование, программирование, тестирование"; }
            default -> { name = "?"; features = "?"; }
        }
        System.out.println("Категория «" + name + "»: " + features);
        Report.add("Категория услуги", name);
    }

    /** Задание 18: калькулятор стоимости услуги (тариф + дополнительные параметры). */
    public void tariffCalculator() {
        System.out.println("\n--- Калькулятор стоимости ---");
        System.out.println("Тарифы: 1 — Базовый (1000/мес), 2 — Стандарт (2500/мес), 3 — Премиум (5000/мес)");
        int tariff = Validation.readInt("Выберите тариф: ", 1, 3);
        int months = Validation.readInt("Срок (месяцев, 1–36): ", 1, 36);
        boolean priority = Validation.readYesNo("Добавить приоритетную поддержку (+500/мес)?");
        boolean storage = Validation.readYesNo("Добавить расширенное хранилище (+300/мес)?");

        int monthly = switch (tariff) {
            case 1 -> 1000;
            case 2 -> 2500;
            case 3 -> 5000;
            default -> 0;
        };
        if (priority) monthly += 500;
        if (storage) monthly += 300;

        double total = (double) monthly * months;
        String discountNote = "без скидки";
        if (months >= 12) {
            total *= 0.9;
            discountNote = "скидка 10% за год и более";
        }
        System.out.printf("Ежемесячно: %d. Итого за %d мес.: %.2f (%s)%n", monthly, months, total, discountNote);
        Report.add("Калькулятор тарифа", String.format("%.2f за %d мес.", total, months));
    }

    /** Задание 19: обработка ошибок с повтором действия. */
    public void errorHandling() {
        System.out.println("\n--- Обработка ошибок выбора ---");
        System.out.println("Выберите действие: 1 — сохранить, 2 — удалить, 3 — отправить");
        while (true) {
            int choice = Validation.readInt("Ваш выбор: ", Integer.MIN_VALUE, Integer.MAX_VALUE);
            String result;
            switch (choice) {
                case 1 -> result = "Данные сохранены";
                case 2 -> result = "Данные удалены";
                case 3 -> result = "Данные отправлены";
                default -> {
                    System.out.println("[Ошибка] Нет такого пункта. Попробуйте ещё раз.");
                    continue;
                }
            }
            System.out.println(result);
            Report.add("Обработка ошибок", result);
            return;
        }
    }

    /** Задание 20: switch + if-else + логические операторы, пять сценариев. */
    public void combinedScenarios() {
        System.out.println("\n--- Комбинированные сценарии ---");
        System.out.println("1. Кредит\n2. Возврат товара\n3. Допуск к экзамену\n4. Бесплатная доставка\n5. Парковка");
        int s = Validation.readInt("Выберите сценарий: ", 1, 5);
        String result;
        switch (s) {
            case 1 -> {
                int age = Validation.readInt("Возраст: ", 0, 120);
                double income = Validation.readDouble("Доход: ", 0, 1_000_000_000);
                boolean debts = Validation.readYesNo("Есть непогашенные долги?");
                result = (age >= 21 && age <= 65 && income >= 200_000 && !debts) ? "Кредит одобрен" : "В кредите отказано";
            }
            case 2 -> {
                int days = Validation.readInt("Дней с покупки: ", 0, 1000);
                boolean receipt = Validation.readYesNo("Есть чек?");
                boolean used = Validation.readYesNo("Товар использовался?");
                if (days <= 14 && receipt && !used) result = "Возврат принят";
                else if (days <= 14 && !used) result = "Возврат возможен по решению менеджера (нет чека)";
                else result = "Возврат невозможен";
            }
            case 3 -> {
                int attendance = Validation.readInt("Посещаемость, %: ", 0, 100);
                int labs = Validation.readInt("Сдано лабораторных (из 10): ", 0, 10);
                result = (attendance >= 70 && labs >= 7) ? "Допущен к экзамену"
                        : (attendance >= 50 || labs >= 5) ? "Допуск условный (нужна отработка)" : "Не допущен";
            }
            case 4 -> {
                double sum = Validation.readDouble("Сумма заказа: ", 0, 1_000_000_000);
                boolean vip = Validation.readYesNo("VIP-клиент?");
                result = (sum >= 5_000 || vip) ? "Доставка бесплатная" : "Доставка платная (200)";
            }
            default -> {
                int hours = Validation.readInt("Часов парковки: ", 1, 72);
                boolean resident = Validation.readYesNo("Житель района?");
                int price = hours <= 1 ? 0 : (hours - 1) * 150;
                if (resident) price /= 2;
                result = "Стоимость парковки: " + price;
            }
        }
        System.out.println(result);
        Report.add("Сценарий №" + s, result);
    }

    // ===================== Блок 5. Индивидуальная разработка (21–24) =====================

    /**
     * Задание 21: индивидуальный модуль — «Подбор абонемента фитнес-клуба».
     * Предметная область: фитнес. Используется шесть условий.
     */
    public void customModule() {
        System.out.println("\n--- Модуль «Фитнес-клуб»: подбор абонемента ---");
        int age = Validation.readInt("Возраст: ", 10, 100);
        int visits = Validation.readInt("Планируемых посещений в неделю (0–14): ", 0, 14);
        boolean pool = Validation.readYesNo("Нужен бассейн?");
        boolean trainer = Validation.readYesNo("Нужен персональный тренер?");
        boolean medical = Validation.readYesNo("Есть медицинская справка?");
        double budget = Validation.readDouble("Бюджет в месяц: ", 0, 1_000_000);

        String result;
        if (!medical) {                                  // условие 1
            result = "Сначала необходимо получить медицинскую справку";
        } else if (age < 16) {                           // условие 2
            result = "Детский абонемент (до 16 лет), занятия в группе";
        } else if (trainer && budget >= 15_000) {        // условие 3
            result = "VIP-абонемент с персональным тренером";
        } else if (pool && visits >= 3 && budget >= 8_000) { // условие 4
            result = "Абонемент «Зал + бассейн»";
        } else if (visits >= 5 || age >= 60) {           // условие 5
            result = "Безлимитный абонемент (или льготный для 60+)";
        } else if (budget >= 3_000) {                    // условие 6
            result = "Базовый абонемент на 8 посещений";
        } else {
            result = "Разовые посещения — бюджет ограничен";
        }
        System.out.println("Рекомендуемый вариант: " + result);
        Report.add("Фитнес-клуб", result);
    }

    /** Задание 22: анализ данных по пяти параметрам. Результат — итоговый балл. */
    public int dataAnalysis() {
        System.out.println("\n--- Анализ кандидата на стажировку (5 параметров) ---");
        double gpa = Validation.readDouble("1) Средний балл (0–5): ", 0, 5);
        int experience = Validation.readInt("2) Опыт программирования, месяцев (0–120): ", 0, 120);
        int java = Validation.readInt("3) Знание Java (0–10): ", 0, 10);
        int english = Validation.readInt("4) Английский язык (0–10): ", 0, 10);
        int motivation = Validation.readInt("5) Мотивация (0–10): ", 0, 10);

        int score = 0;
        score += gpa >= 4.5 ? 20 : gpa >= 3.5 ? 14 : gpa >= 3.0 ? 8 : 3;
        score += experience >= 24 ? 20 : experience >= 12 ? 14 : experience >= 6 ? 8 : 2;
        score += java * 3;          // до 30
        score += english * 2;       // до 20
        score += motivation;        // до 10
        String verdict = score >= 70 ? "рекомендован" : score >= 50 ? "в резерве" : "не рекомендован";
        System.out.println("Итоговый балл: " + score + " из 100 → кандидат " + verdict);
        Report.add("Анализ кандидата", score + " баллов, " + verdict);
        return score;
    }

    /** Задание 23: три уровня результата — низкий, средний, высокий. */
    public String levelOfReadiness() {
        System.out.println("\n--- Уровень подготовки по Java ---");
        int hours = Validation.readInt("Часов практики в неделю (0–80): ", 0, 80);
        int solved = Validation.readInt("Решено задач (0–500): ", 0, 500);
        int tests = Validation.readInt("Средний результат тестов, % (0–100): ", 0, 100);

        String level;
        if (solved >= 100 && tests >= 80 && hours >= 10) {
            level = "ВЫСОКИЙ";
        } else if (solved >= 30 && tests >= 55) {
            level = "СРЕДНИЙ";
        } else {
            level = "НИЗКИЙ";
        }
        System.out.println("Уровень подготовки: " + level);
        Report.add("Уровень подготовки", level);
        return level;
    }

    /** Задание 24: персонализированные рекомендации по комбинации условий. */
    public void personalRecommendations() {
        System.out.println("\n--- Персональные рекомендации ---");
        System.out.println("Интерес: 1 — веб, 2 — игры, 3 — данные, 4 — мобильные приложения");
        int interest = Validation.readInt("Ваш интерес: ", 1, 4);
        System.out.println("Уровень: 1 — новичок, 2 — средний, 3 — продвинутый");
        int level = Validation.readInt("Ваш уровень: ", 1, 3);
        boolean teamwork = Validation.readYesNo("Любите работать в команде?");

        String direction = switch (interest) {
            case 1 -> "Spring Boot и веб-разработка";
            case 2 -> "библиотека LibGDX и игровая логика";
            case 3 -> "Java Streams, коллекции и работа с данными";
            default -> "Android и Kotlin/Java";
        };
        String step;
        if (level == 1) {
            step = "Сначала закрепите основы: условия, циклы, классы. Затем — " + direction + ".";
        } else if (level == 2 && teamwork) {
            step = "Участвуйте в командном проекте по теме: " + direction + ".";
        } else if (level == 2) {
            step = "Сделайте личный мини-проект по теме: " + direction + ".";
        } else {
            step = teamwork ? "Вносите вклад в open-source: " + direction + "."
                            : "Создайте портфолио-проект: " + direction + ".";
        }
        System.out.println("Рекомендация: " + step);
        Report.add("Персональная рекомендация", step);
    }

    // ===================== Задание 25. Комплексная оценка =====================

    /** Финальная версия: объединяет проверки и выдаёт итоговое решение. */
    public void finalDecision() {
        System.out.println("\n--- КОМПЛЕКСНАЯ ОЦЕНКА (финальный модуль) ---");
        String name = Validation.readText("Имя клиента: ");
        int age = Validation.readInt("Возраст: ", 0, 120);
        boolean blocked = Validation.readYesNo("Клиент заблокирован?");
        double income = Validation.readDouble("Доход в месяц: ", 0, 1_000_000_000);
        double expenses = Validation.readDouble("Расходы в месяц: ", 0, 1_000_000_000);
        int points = Validation.readInt("Баллы тестирования (0–100): ", 0, 100);
        boolean twoFa = Validation.readYesNo("Включена двухфакторная защита?");

        List<String> reasons = new ArrayList<>();
        int score = 0;

        if (age >= 18) { score += 2; reasons.add("совершеннолетний"); } else { reasons.add("возраст меньше 18 лет"); }
        if (!blocked) { score += 2; reasons.add("аккаунт не заблокирован"); } else { reasons.add("аккаунт заблокирован"); }
        if (income > expenses) { score += 2; reasons.add("доходы превышают расходы"); } else { reasons.add("расходы не меньше доходов"); }
        if (points >= 75) { score += 3; reasons.add("высокий результат тестирования"); }
        else if (points >= 50) { score += 1; reasons.add("результат тестирования средний"); }
        else { reasons.add("низкий результат тестирования"); }
        if (twoFa) { score += 1; reasons.add("включена двухфакторная защита"); } else { reasons.add("нет двухфакторной защиты"); }

        String decision;
        if (blocked || age < 18) {
            decision = "ОТКАЗАНО";
        } else if (score >= 8) {
            decision = "ОДОБРЕНО";
        } else if (score >= 5) {
            decision = "НА РАССМОТРЕНИИ";
        } else {
            decision = "ОТКАЗАНО";
        }
        Report.printDecision(name, decision + " (баллов: " + score + " из 10)", reasons);
        Report.add("Комплексная оценка: " + name, decision + ", " + score + " б.");
    }
}
